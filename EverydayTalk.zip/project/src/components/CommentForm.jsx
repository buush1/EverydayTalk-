import React, { useState } from 'react';

const CommentForm = ({ onSubmit }) => {
  const [username, setUsername] = useState('');
  const [text, setText] = useState('');
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    
    if (!username.trim()) {
      newErrors.username = 'Username is required';
    }
    
    if (!text.trim()) {
      newErrors.text = 'Comment cannot be empty';
    } else if (text.trim().length < 5) {
      newErrors.text = 'Comment must be at least 5 characters';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validate()) {
      onSubmit({ username, text });
      setUsername('');
      setText('');
      setErrors({});
    }
  };

  return (
    <form className="comment-form" onSubmit={handleSubmit}>
      <h4>Leave a Comment</h4>
      
      <div className="form-group">
        <label htmlFor="username" className="form-label">Your Name</label>
        <input
          type="text"
          id="username"
          className="form-input"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        {errors.username && <div style={{ color: 'var(--color-error)', fontSize: '0.875rem', marginTop: 'var(--spacing-1)' }}>{errors.username}</div>}
      </div>
      
      <div className="form-group">
        <label htmlFor="comment" className="form-label">Your Comment</label>
        <textarea
          id="comment"
          className="form-textarea"
          value={text}
          onChange={(e) => setText(e.target.value)}
        ></textarea>
        {errors.text && <div style={{ color: 'var(--color-error)', fontSize: '0.875rem', marginTop: 'var(--spacing-1)' }}>{errors.text}</div>}
      </div>
      
      <button type="submit" className="submit-button">
        Post Comment
      </button>
    </form>
  );
};

export default CommentForm;