import React, { useState, useEffect } from 'react';
import { ThumbsUp, ThumbsDown } from 'lucide-react';

const LikeDislikeButtons = ({ articleId, likes, dislikes, onReaction }) => {
  const localStorageKey = `article-${articleId}-reaction`;
  const [userReaction, setUserReaction] = useState(null);
  
  // Load user's previous reaction from localStorage
  useEffect(() => {
    const savedReaction = localStorage.getItem(localStorageKey);
    if (savedReaction) {
      setUserReaction(savedReaction);
    }
  }, [localStorageKey]);
  
  const handleReaction = (reaction) => {
    // If user already reacted this way, do nothing
    if (userReaction === reaction) {
      return;
    }
    
    // Save user's reaction to localStorage
    localStorage.setItem(localStorageKey, reaction);
    setUserReaction(reaction);
    
    // Call the parent component's handler
    onReaction(articleId, reaction);
  };
  
  return (
    <div className="engagement-actions">
      <button 
        className={`engagement-button like-button ${userReaction === 'like' ? 'active' : ''}`}
        onClick={() => handleReaction('like')}
        style={userReaction === 'like' ? { backgroundColor: 'rgba(56, 161, 105, 0.2)', color: 'var(--color-success)' } : {}}
        aria-label="Like this article"
      >
        <ThumbsUp size={18} />
        <span>{likes}</span>
      </button>
      
      <button 
        className={`engagement-button dislike-button ${userReaction === 'dislike' ? 'active' : ''}`}
        onClick={() => handleReaction('dislike')}
        style={userReaction === 'dislike' ? { backgroundColor: 'rgba(229, 62, 62, 0.2)', color: 'var(--color-error)' } : {}}
        aria-label="Dislike this article"
      >
        <ThumbsDown size={18} />
        <span>{dislikes}</span>
      </button>
    </div>
  );
};

export default LikeDislikeButtons;