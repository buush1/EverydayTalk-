import React, { useContext, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { ArticleContext } from '../context/ArticleContext';
import ArticleCard from '../components/ArticleCard';
import Sidebar from '../components/Sidebar';
import '../styles/category.css';

const CategoryPage = () => {
  const { category } = useParams();
  const { getArticlesByCategory } = useContext(ArticleContext);
  const [articles, setArticles] = useState([]);
  const [categoryTitle, setCategoryTitle] = useState('');
  
  useEffect(() => {
    // Capitalize the first letter of the category
    const formattedCategory = category.charAt(0).toUpperCase() + category.slice(1);
    setCategoryTitle(formattedCategory);
    
    // Get articles for this category
    const categoryArticles = getArticlesByCategory(formattedCategory);
    setArticles(categoryArticles);
  }, [category, getArticlesByCategory]);
  
  return (
    <main className="category-page">
      <div className="container">
        <header className="category-header">
          <h1 className="category-title">{categoryTitle} News</h1>
          <p className="category-description">
            The latest news and insights from the world of {categoryTitle.toLowerCase()}.
          </p>
        </header>
        
        <div className="main-layout">
          <section className="category-articles">
            {articles.length > 0 ? (
              <div className="articles-grid">
                {articles.map(article => (
                  <ArticleCard key={article.id} article={article} />
                ))}
              </div>
            ) : (
              <div className="empty-category">
                <p>No articles found in this category.</p>
              </div>
            )}
          </section>
          
          <Sidebar />
        </div>
      </div>
    </main>
  );
};

export default CategoryPage;