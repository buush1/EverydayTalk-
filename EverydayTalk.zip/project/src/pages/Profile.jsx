import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { ArticleContext } from '../context/ArticleContext';
import { Calendar, Eye, Clock, BookOpen, ThumbsUp, MessageSquare, FileSearch } from 'lucide-react';
import '../styles/profile.css';

const Profile = () => {
  const { getViewedArticleObjects } = useContext(ArticleContext);
  const viewedArticles = getViewedArticleObjects();
  
  // Format the publication date
  const formatDate = (dateString) => {
    const options = { month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Calculate total likes, comments and views across viewed articles
  const totalLikes = viewedArticles.reduce((sum, article) => sum + article.likes, 0);
  const totalComments = viewedArticles.reduce((sum, article) => sum + article.comments.length, 0);
  const totalViews = viewedArticles.reduce((sum, article) => sum + article.viewCount, 0);
  
  return (
    <main className="profile">
      <div className="container">
        <header className="profile-header">
          <h1 className="profile-title">Your Reading Profile</h1>
          <p className="profile-subtitle">
            Track your reading history and engagement with articles
          </p>
          
          <div className="stats-container">
            <div className="stat-card">
              <div className="stat-value">{viewedArticles.length}</div>
              <div className="stat-label">Articles Read</div>
            </div>
            
            <div className="stat-card">
              <div className="stat-value">{totalLikes}</div>
              <div className="stat-label">Total Article Likes</div>
            </div>
            
            <div className="stat-card">
              <div className="stat-value">{totalComments}</div>
              <div className="stat-label">Comments on Articles</div>
            </div>
          </div>
        </header>
        
        <section className="history-section">
          <h2 className="section-title">
            <Clock size={24} style={{ verticalAlign: 'middle', marginRight: 'var(--spacing-2)' }} />
            Reading History
          </h2>
          
          {viewedArticles.length > 0 ? (
            <ul className="history-list">
              {viewedArticles.map(article => (
                <li key={article.id} className="history-item">
                  <div className="history-image">
                    <img src={article.thumbnail} alt={article.title} />
                  </div>
                  
                  <div className="history-content">
                    <h3 className="history-title">
                      <Link to={`/article/${article.id}`}>{article.title}</Link>
                    </h3>
                    <div className="history-meta">
                      <span className="history-date">
                        <Calendar size={14} />
                        {formatDate(article.publicationDate)}
                      </span>
                      <span className="history-views">
                        <Eye size={14} />
                        {article.viewCount} views
                      </span>
                    </div>
                  </div>
                  
                  <span className="history-category">{article.category}</span>
                </li>
              ))}
            </ul>
          ) : (
            <div className="empty-state">
              <div className="empty-state-icon">
                <BookOpen size={48} />
              </div>
              <h3 className="empty-state-title">No Reading History Yet</h3>
              <p className="empty-state-text">
                Start exploring articles to build your reading history.
                Your viewed articles will appear here.
              </p>
              <Link to="/" className="empty-state-button">Discover Articles</Link>
            </div>
          )}
        </section>
      </div>
    </main>
  );
};

export default Profile;