import React, { createContext, useState, useEffect } from 'react';
import newsData from '../data/newsData';

export const ArticleContext = createContext();

export const ArticleProvider = ({ children }) => {
  // Initialize state with data from newsData or localStorage if available
  const [articles, setArticles] = useState(() => {
    const savedArticles = localStorage.getItem('articles');
    return savedArticles ? JSON.parse(savedArticles) : newsData;
  });
  
  // Track viewed articles for user history
  const [viewedArticles, setViewedArticles] = useState(() => {
    const savedViewedArticles = localStorage.getItem('viewedArticles');
    return savedViewedArticles ? JSON.parse(savedViewedArticles) : [];
  });
  
  // Save to localStorage whenever articles or viewedArticles change
  useEffect(() => {
    localStorage.setItem('articles', JSON.stringify(articles));
  }, [articles]);
  
  useEffect(() => {
    localStorage.setItem('viewedArticles', JSON.stringify(viewedArticles));
  }, [viewedArticles]);
  
  // Get an article by ID
  const getArticle = (id) => {
    return articles.find(article => article.id === Number(id));
  };
  
  // Increment view count for an article
  const incrementViews = (id) => {
    setArticles(prevArticles => {
      return prevArticles.map(article => {
        if (article.id === Number(id)) {
          // Add to viewed articles history if not already there
          if (!viewedArticles.includes(article.id)) {
            setViewedArticles(prev => [...prev, article.id]);
          }
          return { ...article, viewCount: article.viewCount + 1 };
        }
        return article;
      });
    });
  };
  
  // Handle like or dislike of an article
  const handleReaction = (id, reaction) => {
    setArticles(prevArticles => {
      return prevArticles.map(article => {
        if (article.id === Number(id)) {
          if (reaction === 'like') {
            return { ...article, likes: article.likes + 1 };
          } else if (reaction === 'dislike') {
            return { ...article, dislikes: article.dislikes + 1 };
          }
        }
        return article;
      });
    });
  };
  
  // Add a comment to an article
  const addComment = (id, comment) => {
    setArticles(prevArticles => {
      return prevArticles.map(article => {
        if (article.id === Number(id)) {
          const newComment = {
            id: article.comments.length + 1,
            ...comment,
            timestamp: new Date().toISOString()
          };
          return { 
            ...article, 
            comments: [...article.comments, newComment] 
          };
        }
        return article;
      });
    });
  };
  
  // Get most viewed articles for trending section
  const getTrendingArticles = () => {
    return [...articles]
      .sort((a, b) => b.viewCount - a.viewCount)
      .slice(0, 3);
  };
  
  // Get articles by category
  const getArticlesByCategory = (category) => {
    return category 
      ? articles.filter(article => article.category === category)
      : articles;
  };
  
  // Get user's viewed article objects
  const getViewedArticleObjects = () => {
    return articles.filter(article => viewedArticles.includes(article.id));
  };
  
  return (
    <ArticleContext.Provider value={{
      articles,
      getArticle,
      incrementViews,
      handleReaction,
      addComment,
      getTrendingArticles,
      getArticlesByCategory,
      viewedArticles,
      getViewedArticleObjects
    }}>
      {children}
    </ArticleContext.Provider>
  );
};

export default ArticleProvider;